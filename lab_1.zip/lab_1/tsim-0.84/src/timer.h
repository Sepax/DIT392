
#ifndef TS_timer_H_
#define TS_timer_H_

void AddTimeOut(tTrainLine train_line);

#endif /* TS_timer_H_ */

