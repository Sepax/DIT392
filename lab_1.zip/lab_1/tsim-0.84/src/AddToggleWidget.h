
#ifndef TS_AddToggleWidget_H_
#define TS_AddToggleWidget_H_

Widget AddToggleWidget(
      String name,
      Widget parent,
      Widget radio_group,
      XtPointer radio_data,
      ArgList args,
      Cardinal num_args);

#endif /* TS_AddToggleWidget_H_ */

