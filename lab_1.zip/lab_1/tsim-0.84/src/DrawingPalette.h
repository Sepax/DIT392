
#ifndef TS_DrawingPalette_H_
#define TS_DrawingPalette_H_

Widget CreateDrawingPalette(
      String name,
      Widget parent,
      tTrainLine train_line);

#endif /* TS_DrawingPalette_H_ */

