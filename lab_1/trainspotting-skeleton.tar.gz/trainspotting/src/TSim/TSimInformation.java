package TSim;

/**
 * Umbrella type for messages from TSim.
 *
 */

public interface TSimInformation {
}
