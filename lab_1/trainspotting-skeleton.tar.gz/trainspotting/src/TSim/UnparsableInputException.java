package TSim;

/* package */ class UnparsableInputException extends Exception {
	public UnparsableInputException(String s) {
		super(s);
	}
}
